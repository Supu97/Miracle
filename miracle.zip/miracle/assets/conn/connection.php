<?php
$fname = $_post['patientFirstName'];
$lname = $_post['patientLastName'];

$conn = mysqli_connect('localhost','root','','patiantdetails');

if(conn->connect_error){
    die('connection failed : '.$conn->connect_error);
}else{
    $stmt = $conn->prepare(INSERT INTO `p_details`(`f_name`, `l_name`) VALUES (?,?)");
    $stmt->bind_param("ss",$fname, $lname);
    $stmt->execute();
    echo "registration succussfull";
    $stmt->close();
    $conn->close();
}
?>