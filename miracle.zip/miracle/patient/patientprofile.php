<?php
// session_start();
// // include_once '../connection/server.php';

// include_once '../assets/conn/dbconnect.php';

// if(!isset($_SESSION['patientSession']))
// {
//  header("Location: ../fail.php");
// }
// $res=mysqli_query($con,"SELECT * FROM patient WHERE icPatient=".$_SESSION['patientSession']);
// $userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Patient Dashboard</title>
        <!-- Bootstrap Core CSS -->
        <!-- <link href="assets/css/bootstrap1.min.css" rel="stylesheet"> -->
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/css/material.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="assets/css/sb-admin.css" rel="stylesheet">
        <!-- Custom Fonts -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div id="wrapper">
            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="patientdashboard.html">Patient Dashboard</a>
                </div>
                <!-- Top Menu Items -->
                
                <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav side-nav">
                        <li>
                            <a href="patientdashboard.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                        </li>
                        <li class="active">
                            <a href="patientprofile.php"><i class="fa fa-fw fa-bar-chart-o"></i> Profile</a>
                        </li>
                        
                            </ul>
                        </li>
                        <li>
                            <a href="blank-page.html"><i class="fa fa-fw fa-file"></i> Blank Page</a>
                        </li>
                        <li>
                            <a href="patientdashboard-rtl.html"><i class="fa fa-fw fa-dashboard"></i> RTL Dashboard</a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </nav>
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                            Patiant Profile
                            </h1>
                            <ol class="breadcrumb">
                               
                                <li class="active">Welcome! Here is your Profile</li>
                            </ol>
                        </div>
                    </div>
                    <!-- /.row -->
                    <!-- template start -->
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
                                
                                
                                <div class="panel panel-info">
                                    <div class="panel-heading">
                                        <h3 class="panel-title"><?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?></h3>
                                    </div>
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-md-3 col-lg-3 " align="center"> <img alt="User Pic" src="http://www.readingfc.co.uk/images/common/bg_player_profile_default_big.png" class="img-circle img-responsive"> </div>
                                            
                                            <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
                                                <div class=" col-md-9 col-lg-9 ">
                                                    <table class="table table-user-information" align="center">
                                                        <tbody>
                                                            <tr>
                                                                <td>Patient Id:</td>
                                                                <td><?php echo $userRow['patientId']; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Patient First Name:</td>
                                                                <td><?php echo $userRow['patientFirstName']; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>PatientLastName</td>
                                                                <td><?php echo $userRow['patientLastName']; ?></td>
                                                            </tr>
                                                            
                                                            
                                                            <tr>
                                                                <td>PatientMaritialStatus</td>
                                                                <td><?php echo $userRow['patientMaritialStatus']; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>PatientDOB</td>
                                                                <td><?php echo $userRow['patientDOB']; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>PatientGender</td>
                                                                <td><?php echo $userRow['patientGender']; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>PatientAddress</td>
                                                                <td><?php echo $userRow['patientAddress']; ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>PatientPhone</td>
                                                                <td><?php echo $userRow['patientPhone']; ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>PatientEmail</td>
                                                                <td><?php echo $userRow['patientEmail']; ?>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <input type="hidden" name="MM_update" value="form1" />
                                                    <input type="hidden" name="patientId" value="<?php echo $userRow['patientId']; ?>" />
                                                    
                                                    
                                                   
                                                    <a href="patientupdateprofile.php" class="btn btn-primary">Update Profile</a>
                                                   
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                        <div class="panel-footer">
                                            
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- template end -->
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /#page-wrapper -->
            </div>
            <!-- /#wrapper -->
            <!-- jQuery -->
            <script src="assets/js/jquery.js"></script>
            <!-- Bootstrap Core JavaScript -->
            <script src="assets/js/bootstrap.min.js"></script>
          
        </body>
    </html>