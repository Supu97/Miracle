<?php
// session_start();
// session_destroy();
// session_unset();
// // include_once '../connection/server.php';
// include_once '../assets/conn/dbconnect.php';
// if(!isset($_SESSION['patientSession']))
// {
// header("Location: ../index.php");
// }
// $usersession = $_SESSION['patientSession'];
// $res=mysql_query("SELECT * FROM patient WHERE icPatient=".$usersession);
// $userRow=mysql_fetch_array($res);
// echo mysql_error();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Patient Dashboard</title>
        <!-- Bootstrap Core CSS -->
        <!-- <link href="assets/css/bootstrap.min.css" rel="stylesheet"> -->
        <link href="assets/css/material.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="assets/css/sb-admin.css" rel="stylesheet">
        <!-- Datepicker -->
        <link href="assets/css/date/bootstrap-datepicker3.css" rel="stylesheet">
        <!-- Custom Fonts -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        
    </head>
    <body>
        <!-- wrapper start -->
        <div id="wrapper">
            
            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="patientdashboard.html">Patient Dashboard</a>
                </div>
                <!-- Top Menu Items -->
                
                <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav side-nav">
                        <li class="active">
                            <a href="patientdashboard.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="patientprofile.php"><i class="fa fa-fw fa-bar-chart-o"></i> Profile</a>
                        </li>
                        
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </nav>
            <!-- Navigation end -->

            <!-- page wrapper start -->
            <div id="page-wrapper">

                <!-- container fluid start -->
                <div class="container-fluid">




                    <!-- Page Heading start-->
                    <div class='row'>
                        <div class='col-lg-12'>
                            <h1 class='page-header'>
                            Dashboard
                            </h1>
                            <ol class='breadcrumb'>
                                <li class='active'>
                                     Wellcome! Here is your Dashboard
                                </li>
                            </ol>
                        </div>
                    </div>
                     <!-- page heading end -->

                    <?php if ($userRow['patientMaritialStatus']=="") {
                     
                 
                    } else {

                    }
                     ?>

                    <!-- 1st section end -->

                   
                    <!-- 2nd section end -->

                    <!-- 3rd section start -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Appointment Status</h3>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover table-striped">
                                        <thead>
                                            <tr>
                                                <th>Appointment Number</th>
                                                <th>Appointment Date</th>
                                                <th>Appointent Time</th>
                                                <th>Doctor Name</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>3326</td>
                                                <td>21/12/2020</td>
                                                <td>3:29 PM</td>
                                                <td>Dr: Himal Melanka</td>
                                            </tr>
                                           
                                        </tbody>
                                    </table>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                    <!-- 3rd section end -->
                </div>
                <!-- /.container-fluid  end-->

            </div>
            <!-- /#page-wrapper end-->

        </div>
        <!-- /#wrapper end -->

        <!-- jQuery -->
        <script src="assets/js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- datepicker script -->
        <script src="assets/js/date/bootstrap-datepicker.js"></script>
        <script src="assets/js/date/moment.js"></script>
        <script src="assets/js/date/transition.js"></script>
        <script src="assets/js/date/collapse.js"></script>

        <!-- script for datepicker start -->
        <script>
        $(document).ready(function(){
            var date_input=$('input[name="date"]'); //our date input has the name "date"
            var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
            date_input.datepicker({
                format: 'yyyy-mm-dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
        </script>
        <!-- script for datepicker end -->
    </body>
</html>